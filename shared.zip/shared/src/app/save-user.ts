export class SaveUser {
    title: string;
    content: string;
    email: string;
    date: Date;

    constructor()
    {

    }
}
