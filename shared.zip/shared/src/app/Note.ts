export class Todo{
    title:string;
    content: string | undefined;
    completed:boolean | undefined;
}